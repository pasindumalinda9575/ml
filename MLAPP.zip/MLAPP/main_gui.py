import os
import re
import numpy as np
from PIL import Image
from psd_tools import PSDImage
import tifffile
import tkinter as tk
from tkinter import messagebox
import threading

# --- CONFIGURATION ARRAYS ---
ORIG_KEYWORDS = ["original", "origin", "raw", "source", "master"]
SEP_KEYWORDS  = ["separation", "separat", "seperat", "refined", "screen", "tech"]

def sanitize_filename(name):
    return re.sub(r'[\\/*?:"<>|]', "", str(name)).strip()

def process_and_save_array(data_array, target_path):
    """
    Enhanced normalization to handle 16-bit, float, and 8-bit TIFF data.
    """
    try:
        # Convert to float for processing
        img_float = data_array.astype(float)
        
        # Handle 3D arrays that might slip through (H, W, 1)
        if len(img_float.shape) == 3:
            img_float = img_float[:, :, 0]

        max_val, min_val = np.max(img_float), np.min(img_float)
        
        # Skip if the channel is completely blank/flat
        if max_val - min_val < 0.001: 
            return False

        # Normalize to 0-255 range
        normalized = (img_float - min_val) * (255.0 / (max_val - min_val))
        
        # Invert logic: RIP screens are usually Black (ink) on White.
        # We want White (ink) on Black for AI training.
        if np.mean(normalized) > 127:
            normalized = 255 - normalized
            
        img = Image.fromarray(normalized.astype('uint8'))
        
        # Final check: is there actually content here?
        if np.mean(np.array(img)) > 0.1:
            img.save(target_path)
            return True
        return False
    except Exception as e:
        print(f"Processing Error: {e}")
        return False

# --- ENGINES ---

def extract_psd_all_channels(filepath, target_dir):
    count = 0
    try:
        psd = PSDImage.open(filepath)
        channel_names = []
        try:
            resources = psd._record.image_resources
            for res in resources:
                if res.resource_id in [1007, 1077]:
                    found_names = re.findall(rb'[\x20-\x7E]{3,}', res.data)
                    for n in found_names:
                        name_str = n.decode('ascii', errors='ignore')
                        if name_str not in ["DisplayInfo", "Opacity", "None"]:
                            channel_names.append(sanitize_filename(name_str))
        except: pass
        
        all_channels_data = psd._record.image_data.get_data(psd._record.header)
        for i, channel_bytes in enumerate(all_channels_data):
            img_np = np.frombuffer(channel_bytes, dtype=np.uint8).reshape((psd.height, psd.width))
            chan_name = channel_names[i] if i < len(channel_names) else f"channel_{i}"
            if process_and_save_array(img_np, os.path.join(target_dir, f"{chan_name}.png")):
                count += 1
        return count
    except Exception: return 0

def extract_tiff_robust(filepath, target_dir):
    """
    Aggressive TIFF extractor that handles interleaved channels and multiple pages.
    """
    count = 0
    try:
        with tifffile.TiffFile(filepath) as tif:
            num_pages = len(tif.pages)
            # Only skip first 3 if it's a standard RGB+Spot file
            start_index = 3 if num_pages > 3 else 0
            
            for i in range(start_index, num_pages):
                page = tif.pages[i]
                data = page.asarray()
                
                # Metadata Name Lookup
                tag_name = page.tags.get(285) or page.tags.get(270)
                base_name = sanitize_filename(tag_name.value) if tag_name else f"screen_{i}"

                # Handle Case: Page contains multiple interleaved channels (H, W, C)
                if len(data.shape) == 3:
                    for c in range(data.shape[2]):
                        chan_data = data[:, :, c]
                        save_name = f"{base_name}_c{c}.png"
                        if process_and_save_array(chan_data, os.path.join(target_dir, save_name)):
                            count += 1
                # Handle Case: Standard single channel page (H, W)
                else:
                    if process_and_save_array(data, os.path.join(target_dir, f"{base_name}.png")):
                        count += 1
        return count
    except Exception as e:
        print(f"TIFF Logic Error: {e}")
        return 0

# --- DISCOVERY LOGIC ---

def find_files_priority(artwork_path):
    orig_path, sep_path = None, None
    all_files = []
    for root, dirs, files in os.walk(artwork_path):
        if any(bad in root for bad in ["__MACOSX", ".DS_Store"]): continue
        for f in files: all_files.append(os.path.join(root, f))

    # Find Original
    for f_path in all_files:
        name = os.path.basename(f_path).lower()
        if any(key in name for key in ORIG_KEYWORDS) or "original" in f_path.lower():
            if name.endswith(('.psd', '.tif', '.tiff', '.png', '.jpg')):
                orig_path = f_path
                break

    # Find Separation (PSD Priority)
    psd_seps, tif_seps = [], []
    for f_path in all_files:
        if orig_path and f_path == orig_path: continue
        name = os.path.basename(f_path).lower()
        is_sep_context = any(key in f_path.lower() for key in SEP_KEYWORDS)
        if name.endswith('.psd'): psd_seps.append((is_sep_context, f_path))
        elif name.endswith(('.tif', '.tiff')): tif_seps.append((is_sep_context, f_path))

    psd_seps.sort(key=lambda x: x[0], reverse=True)
    tif_seps.sort(key=lambda x: x[0], reverse=True)

    if psd_seps: sep_path = psd_seps[0][1]
    elif tif_seps: sep_path = tif_seps[0][1]
    return orig_path, sep_path

# --- GUI ---

class RipApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Universal RIP Extractor v8.0")
        self.root.geometry("750x550")
        self.root.configure(bg="#1a1a1a")
        tk.Label(root, text="RIP ROBUST EXTRACTION", font=("Arial", 12, "bold"), fg="#00FF00", bg="#1a1a1a").pack(pady=15)
        self.log_box = tk.Text(root, height=20, width=85, bg="#000", fg="#00FF00", font=("Consolas", 9))
        self.log_box.pack(pady=5, padx=20)
        self.btn = tk.Button(root, text="RUN PROCESS", bg="#333", fg="white", font=("Arial", 10, "bold"), command=self.start, height=2, width=30)
        self.btn.pack(pady=15)

    def log(self, msg):
        self.log_box.insert(tk.END, f"> {msg}\n"); self.log_box.see(tk.END); self.root.update_idletasks()

    def start(self):
        self.btn.config(state=tk.DISABLED)
        threading.Thread(target=self.run_process, daemon=True).start()

    def run_process(self):
        base, raw_dir, screen_dir = "Artworks", "input_raw", "output_screens"
        for d in [raw_dir, screen_dir]: os.makedirs(d, exist_ok=True)
        
        folders = [f for f in os.listdir(base) if os.path.isdir(os.path.join(base, f)) and not f.startswith('.')]
        for folder in folders:
            self.log(f"📁 {folder}")
            orig_path, sep_path = find_files_priority(os.path.join(base, folder))
            
            if orig_path:
                try:
                    with Image.open(orig_path) as img:
                        img.seek(0); img.convert("RGB").save(os.path.join(raw_dir, f"{folder}.png"))
                    self.log(f"  ✅ Original Found")
                except: pass

            if sep_path:
                target_path = os.path.join(screen_dir, folder); os.makedirs(target_path, exist_ok=True)
                if sep_path.lower().endswith('.psd'):
                    res = extract_psd_all_channels(sep_path, target_path)
                else:
                    res = extract_tiff_robust(sep_path, target_path)
                self.log(f"  ✅ Screens Extracted: {res}")
            else: self.log("  ⚠️ No Screens Found")

        self.log("\nComplete."); self.btn.config(state=tk.NORMAL)
        messagebox.showinfo("Done", "Process complete.")

if __name__ == "__main__":
    root = tk.Tk(); app = RipApp(root); root.mainloop()