# import os, sys, io
# import numpy as np
# from PIL import Image
# from svglib.svglib import svg2rlg
# from reportlab.graphics import renderPM

# TILE_SIZE = 256
# SKIP_EXISTING = "-d" in sys.argv

# def batch_chop(clean_dir="input_cleaned", raw_dir="input_raw", output_base="training_tiles"):
#     for filename in os.listdir(clean_dir):
#         design_name = os.path.splitext(filename)[0]
#         design_out_folder = os.path.join(output_base, design_name)
        
#         if SKIP_EXISTING and os.path.exists(design_out_folder):
#             print(f"Skipping {design_name} tiles (Exists)")
#             continue
            
#         # Open the Clean Master Map (always a PNG)
#         img_clean = Image.open(os.path.join(clean_dir, filename)).convert("RGB")
        
#         # 1. Find the matching Raw file
#         raw_path = None
#         for f in os.listdir(raw_dir):
#             if os.path.splitext(f)[0] == design_name:
#                 raw_path = os.path.join(raw_dir, f)
#                 break
        
#         if not raw_path: 
#             print(f"No raw pair found for {design_name}")
#             continue

#         # 2. Handle Raw file loading (Check for SVG)
#         if raw_path.lower().endswith('.svg'):
#             print(f"Rasterizing SVG for chopper: {raw_path}")
#             drawing = svg2rlg(raw_path)
#             png_data = io.BytesIO()
#             renderPM.drawToFile(drawing, png_data, fmt="PNG")
#             png_data.seek(0)
#             img_raw = Image.open(png_data).convert("RGB")
#         else:
#             img_raw = Image.open(raw_path).convert("RGB")

#         # 3. Sync sizes and Chop
#         img_raw = img_raw.resize(img_clean.size, Image.Resampling.LANCZOS)
#         os.makedirs(design_out_folder, exist_ok=True)
        
#         count = 0
#         for y in range(0, img_clean.size[1] - TILE_SIZE, TILE_SIZE):
#             for x in range(0, img_clean.size[0] - TILE_SIZE, TILE_SIZE):
#                 box = (x, y, x + TILE_SIZE, y + TILE_SIZE)
#                 t_clean = img_clean.crop(box)
#                 t_raw = img_raw.crop(box)
                
#                 # Filter blank tiles
#                 if np.mean(np.array(t_clean.convert("L"))) > 250: continue

#                 combined = Image.new("RGB", (512, 256))
#                 combined.paste(t_clean, (0,0))
#                 combined.paste(t_raw, (256,0))
#                 combined.save(os.path.join(design_out_folder, f"tile_{count}.png"))
#                 count += 1
#         print(f"Chopped {design_name}: {count} tiles.")

# if __name__ == "__main__":
#     batch_chop()

# import os, sys, io
# import numpy as np
# from PIL import Image

# TILE_SIZE = 256
# SKIP_EXISTING = "-d" in sys.argv

# def batch_chop(clean_dir="input_cleaned", raw_dir="input_raw", output_base="training_tiles"):
#     # Ensure the output directory exists
#     os.makedirs(output_base, exist_ok=True)
    
#     # Iterate through the Cleaned Master Maps (the "Answers")
#     for filename in os.listdir(clean_dir):
#         if not filename.endswith('.png'): continue
        
#         design_name = os.path.splitext(filename)[0]
#         design_out_folder = os.path.join(output_base, design_name)
        
#         if SKIP_EXISTING and os.path.exists(design_out_folder):
#             print(f"Skipping {design_name} tiles (Exists)")
#             continue
            
#         # 1. Open the Clean Master Map
#         clean_path = os.path.join(clean_dir, filename)
#         img_clean = Image.open(clean_path).convert("RGB")
        
#         # 2. Find the matching Raw Artwork PNG in input_raw
#         # Based on your new structure, the PNG is named after the folder
#         raw_path = os.path.join(raw_dir, f"{design_name}.png")
        
#         if not os.path.exists(raw_path):
#             print(f"No raw artwork PNG found for {design_name} at {raw_path}")
#             continue

#         img_raw = Image.open(raw_path).convert("RGB")

#         # 3. Sync sizes (Raw must match Clean exactly for pixel-perfect training)
#         if img_raw.size != img_clean.size:
#             img_raw = img_raw.resize(img_clean.size, Image.Resampling.LANCZOS)
        
#         os.makedirs(design_out_folder, exist_ok=True)
        
#         print(f"Chopping {design_name}...")
        
#         count = 0
#         width, height = img_clean.size
        
#         # Slide the window across the image
#         for y in range(0, height - TILE_SIZE, TILE_SIZE):
#             for x in range(0, width - TILE_SIZE, TILE_SIZE):
#                 box = (x, y, x + TILE_SIZE, y + TILE_SIZE)
                
#                 t_clean = img_clean.crop(box)
#                 t_raw = img_raw.crop(box)
                
#                 # FILTER BLANK TILES
#                 # Convert to grayscale and check mean brightness.
#                 # If mean is < 2 (mostly black), it means there is no ink/design here.
#                 if np.mean(np.array(t_clean.convert("L"))) < 2: 
#                     continue

#                 # Create the side-by-side training pair (512x256)
#                 # Left side: Clean Map (Target) | Right side: Raw Image (Input)
#                 combined = Image.new("RGB", (512, 256))
#                 combined.paste(t_clean, (0, 0))
#                 combined.paste(t_raw, (256, 0))
                
#                 combined.save(os.path.join(design_out_folder, f"tile_{count}.png"))
#                 count += 1
                
#         print(f"  [DONE] Created {count} tiles in {design_out_folder}")

# if __name__ == "__main__":
#     batch_chop()

# import os
# import tkinter as tk
# from tkinter import ttk
# from PIL import Image, ImageTk
# import numpy as np
# import threading

# # --- CONFIGURATION ---
# TILE_SIZE = 256
# PAD_COLOR = (255, 0, 255) # Magenta
# CLEAN_DIR = "input_cleaned"
# RAW_DIR = "input_raw"
# OUTPUT_BASE = "training_tiles"

# class AlignmentGUI:
#     def __init__(self, root, file_list):
#         self.root = root
#         self.file_list = file_list
#         self.current_idx = 0
#         self.off_x, self.off_y = 0, 0
#         self.is_processing = False
        
#         self.root.title("AI Training Data Aligner")
#         self.root.geometry("1100x900")

#         # Left Side: Image Canvas
#         self.canvas = tk.Canvas(root, width=800, height=800, bg="#222")
#         self.canvas.pack(side=tk.LEFT, padx=10, pady=10)

#         # Right Side: Controls Panel
#         self.panel = tk.Frame(root, width=250)
#         self.panel.pack(side=tk.RIGHT, fill=tk.Y, padx=10)

#         self.info_label = tk.Label(self.panel, text="Alignment Controls", font=("Arial", 14, "bold"))
#         self.info_label.pack(pady=10)

#         # Directional Buttons
#         btn_frame = tk.Frame(self.panel)
#         btn_frame.pack(pady=10)
#         tk.Button(btn_frame, text="▲", width=5, command=lambda: self.nudge(0, -1)).grid(row=0, column=1)
#         tk.Button(btn_frame, text="◀", width=5, command=lambda: self.nudge(-1, 0)).grid(row=1, column=0)
#         tk.Button(btn_frame, text="▶", width=5, command=lambda: self.nudge(1, 0)).grid(row=1, column=2)
#         tk.Button(btn_frame, text="▼", width=5, command=lambda: self.nudge(0, 1)).grid(row=2, column=1)

#         self.offset_label = tk.Label(self.panel, text="Offset: X=0, Y=0", font=("Courier", 10))
#         self.offset_label.pack()

#         tk.Button(self.panel, text="Reset (R)", bg="#ff9999", command=self.reset_offset).pack(pady=5)

#         # Progress Section
#         tk.Label(self.panel, text="Processing Progress:").pack(pady=(20, 0))
#         self.progress = ttk.Progressbar(self.panel, orient=tk.HORIZONTAL, length=200, mode='determinate')
#         self.progress.pack(pady=5)

#         self.btn_save = tk.Button(self.panel, text="SAVE & CHOP (Enter)", bg="#99ff99", font=("Arial", 12, "bold"), 
#                                   height=2, command=self.process_current)
#         self.btn_save.pack(pady=20, fill=tk.X)

#         # Log Window
#         tk.Label(self.panel, text="System Log:").pack()
#         self.log = tk.Text(self.panel, height=15, width=30, font=("Courier", 8), bg="#eee")
#         self.log.pack()

#         # Key Bindings
#         self.root.bind("<Up>", lambda e: self.nudge(0, -1))
#         self.root.bind("<Down>", lambda e: self.nudge(0, 1))
#         self.root.bind("<Left>", lambda e: self.nudge(-1, 0))
#         self.root.bind("<Right>", lambda e: self.nudge(1, 0))
#         self.root.bind("<Shift-Up>", lambda e: self.nudge(0, -10))
#         self.root.bind("<Shift-Down>", lambda e: self.nudge(0, 10))
#         self.root.bind("<Return>", lambda e: self.process_current())
#         self.root.bind("r", lambda e: self.reset_offset())

#         self.load_images()

#     def write_log(self, message):
#         self.log.insert(tk.END, message + "\n")
#         self.log.see(tk.END)

#     def reset_offset(self):
#         self.off_x, self.off_y = 0, 0
#         self.update_display()
#         self.write_log("Offsets reset to 0.")

#     def load_images(self):
#         if self.current_idx >= len(self.file_list):
#             self.write_log("--- ALL FILES FINISHED ---")
#             self.btn_save.config(state=tk.DISABLED)
#             return

#         filename = self.file_list[self.current_idx]
#         self.design_name = os.path.splitext(filename)[0]
#         self.write_log(f"Loading: {self.design_name}")

#         self.img_clean = Image.open(os.path.join(CLEAN_DIR, filename)).convert("RGB")
#         self.img_raw = Image.open(os.path.join(RAW_DIR, f"{self.design_name}.png")).convert("RGB")
        
#         self.p_clean = self.img_clean.resize((800, 800), Image.NEAREST)
#         self.p_raw = self.img_raw.resize((800, 800), Image.NEAREST)
#         self.update_display()

#     def nudge(self, dx, dy):
#         if self.is_processing: return
#         self.off_x += dx
#         self.off_y += dy
#         self.update_display()

#     def update_display(self):
#         base = self.p_clean.copy()
#         shifted_raw = Image.new("RGB", (800, 800), (0, 0, 0))
#         shifted_raw.paste(self.p_raw, (self.off_x, self.off_y))
        
#         blended = Image.blend(base, shifted_raw, alpha=0.5)
#         self.tk_img = ImageTk.PhotoImage(blended)
#         self.canvas.create_image(400, 400, image=self.tk_img)
#         self.offset_label.config(text=f"Offset: X={self.off_x}, Y={self.off_y}")

#     def process_current(self):
#         if self.is_processing: return
#         self.is_processing = True
#         self.btn_save.config(state=tk.DISABLED, text="Chipping...")
        
#         # Run chopping in a separate thread so the GUI doesn't freeze
#         scale = self.img_clean.width / 800
#         dx, dy = int(self.off_x * scale), int(self.off_y * scale)
        
#         threading.Thread(target=self.chop_thread, args=(dx, dy), daemon=True).start()

#     def chop_thread(self, dx, dy):
#         folder = os.path.join(OUTPUT_BASE, self.design_name)
#         os.makedirs(folder, exist_ok=True)
#         arr_c, arr_r = np.array(self.img_clean), np.array(self.img_raw)
#         h, w, _ = arr_c.shape
        
#         tiles_y = list(range(0, h, TILE_SIZE))
#         tiles_x = list(range(0, w, TILE_SIZE))
#         total_steps = len(tiles_y) * len(tiles_x)
        
#         count, step = 0, 0
#         for y in tiles_y:
#             for x in tiles_x:
#                 y_end, x_end = y + TILE_SIZE, x + TILE_SIZE
#                 t_clean = arr_c[y:y_end, x:x_end]
                
#                 ry, rx = y - dy, x - dx # Realignment
#                 ry_e, rx_e = ry + TILE_SIZE, rx + TILE_SIZE
                
#                 if ry < 0 or rx < 0 or ry_e > h or rx_e > w:
#                     t_raw = np.full((TILE_SIZE, TILE_SIZE, 3), PAD_COLOR, dtype=np.uint8)
#                 else:
#                     t_raw = arr_r[ry:ry_e, rx:rx_e]

#                 # Logical Edge Padding
#                 if t_clean.shape[0] < TILE_SIZE or t_clean.shape[1] < TILE_SIZE:
#                     pad = np.full((TILE_SIZE, TILE_SIZE, 3), PAD_COLOR, dtype=np.uint8)
#                     pad[:t_clean.shape[0], :t_clean.shape[1]] = t_clean
#                     t_clean = pad

#                 if np.mean(t_clean) > 2:
#                     combined = np.concatenate((t_clean, t_raw), axis=1)
#                     Image.fromarray(combined).save(os.path.join(folder, f"tile_{count}.png"))
#                     count += 1
                
#                 step += 1
#                 if step % 10 == 0:
#                     self.progress['value'] = (step / total_steps) * 100
#                     self.root.update_idletasks()

#         self.write_log(f"Success! {count} tiles saved.")
#         self.is_processing = False
#         self.btn_save.config(state=tk.NORMAL, text="SAVE & CHOP (Enter)")
#         self.progress['value'] = 0
#         self.current_idx += 1
#         self.off_x, self.off_y = 0, 0
#         self.root.after(10, self.load_images)

# if __name__ == "__main__":
#     files = [f for f in os.listdir(CLEAN_DIR) if f.endswith('.png')]
#     root = tk.Tk()
#     AlignmentGUI(root, files)
#     root.mainloop()

import os
import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
import numpy as np
import threading

# --- CONFIGURATION ---
TILE_SIZE = 256
CLEAN_DIR = "input_cleaned"
RAW_DIR = "input_raw"
OUTPUT_BASE = "training_tiles"

class AlignmentGUI:
    def __init__(self, root, file_list):
        self.root = root
        self.file_list = file_list
        self.current_idx = 0
        self.off_x, self.off_y = 0, 0
        self.is_processing = False
        
        self.root.title("AI Training Data Aligner (Overlap Mode)")
        self.root.geometry("1150x900")

        # Left Side: Image Canvas
        self.canvas = tk.Canvas(root, width=800, height=800, bg="#1a1a1a")
        self.canvas.pack(side=tk.LEFT, padx=15, pady=10)

        # Right Side: Controls Panel
        self.panel = tk.Frame(root, width=300)
        self.panel.pack(side=tk.RIGHT, fill=tk.Y, padx=15)

        tk.Label(self.panel, text="Alignment Controls", font=("Arial", 14, "bold")).pack(pady=10)

        # Directional Buttons
        btn_frame = tk.Frame(self.panel)
        btn_frame.pack(pady=10)
        tk.Button(btn_frame, text="▲", width=6, height=2, command=lambda: self.nudge(0, -1)).grid(row=0, column=1)
        tk.Button(btn_frame, text="◀", width=6, height=2, command=lambda: self.nudge(-1, 0)).grid(row=1, column=0)
        tk.Button(btn_frame, text="▶", width=6, height=2, command=lambda: self.nudge(1, 0)).grid(row=1, column=2)
        tk.Button(btn_frame, text="▼", width=6, height=2, command=lambda: self.nudge(0, 1)).grid(row=2, column=1)

        self.offset_label = tk.Label(self.panel, text="Offset: X=0, Y=0", font=("Courier", 11, "bold"), fg="blue")
        self.offset_label.pack(pady=5)

        tk.Button(self.panel, text="Reset Alignment (R)", bg="#ff9999", command=self.reset_offset).pack(pady=5, fill=tk.X)
        tk.Button(self.panel, text="Skip This Design", bg="#cccccc", command=self.skip_design).pack(pady=5, fill=tk.X)

        # Progress Section
        tk.Label(self.panel, text="Processing Overlap Area:").pack(pady=(20, 0))
        self.progress = ttk.Progressbar(self.panel, orient=tk.HORIZONTAL, length=250, mode='determinate')
        self.progress.pack(pady=5)

        self.btn_save = tk.Button(self.panel, text="CHOP OVERLAP (Enter)", bg="#4CAF50", fg="white", 
                                  font=("Arial", 12, "bold"), height=2, command=self.process_current)
        self.btn_save.pack(pady=20, fill=tk.X)

        # Log Window
        tk.Label(self.panel, text="Process Log:").pack()
        self.log = tk.Text(self.panel, height=20, width=35, font=("Courier", 8), bg="#f4f4f4")
        self.log.pack()

        # Key Bindings
        self.root.bind("<Up>", lambda e: self.nudge(0, -1))
        self.root.bind("<Down>", lambda e: self.nudge(0, 1))
        self.root.bind("<Left>", lambda e: self.nudge(-1, 0))
        self.root.bind("<Right>", lambda e: self.nudge(1, 0))
        self.root.bind("<Shift-Up>", lambda e: self.nudge(0, -10))
        self.root.bind("<Shift-Down>", lambda e: self.nudge(0, 10))
        self.root.bind("<Shift-Left>", lambda e: self.nudge(-10, 0))
        self.root.bind("<Shift-Right>", lambda e: self.nudge(10, 0))
        self.root.bind("<Return>", lambda e: self.process_current())
        self.root.bind("r", lambda e: self.reset_offset())

        self.load_images()

    def write_log(self, message):
        self.log.insert(tk.END, f"> {message}\n")
        self.log.see(tk.END)

    def skip_design(self):
        self.write_log(f"Skipped: {self.design_name}")
        self.next_design()

    def reset_offset(self):
        self.off_x, self.off_y = 0, 0
        self.update_display()

    def load_images(self):
        if self.current_idx >= len(self.file_list):
            self.write_log("COMPLETE: All files processed.")
            return

        filename = self.file_list[self.current_idx]
        self.design_name = os.path.splitext(filename)[0]
        self.write_log(f"Loading: {self.design_name}")

        self.img_clean = Image.open(os.path.join(CLEAN_DIR, filename)).convert("RGB")
        self.img_raw = Image.open(os.path.join(RAW_DIR, f"{self.design_name}.png")).convert("RGB")
        
        self.p_clean = self.img_clean.resize((800, 800), Image.NEAREST)
        self.p_raw = self.img_raw.resize((800, 800), Image.NEAREST)
        self.update_display()

    def nudge(self, dx, dy):
        if self.is_processing: return
        self.off_x += dx
        self.off_y += dy
        self.update_display()

    def update_display(self):
        base = self.p_clean.copy()
        overlay = Image.new("RGB", (800, 800), (0, 0, 0))
        overlay.paste(self.p_raw, (self.off_x, self.off_y))
        blended = Image.blend(base, overlay, alpha=0.5)
        self.tk_img = ImageTk.PhotoImage(blended)
        self.canvas.create_image(400, 400, image=self.tk_img)
        self.offset_label.config(text=f"Offset: X={self.off_x}, Y={self.off_y}")

    def process_current(self):
        if self.is_processing: return
        self.is_processing = True
        self.btn_save.config(state=tk.DISABLED, text="Processing Area...")
        
        scale = self.img_clean.width / 800
        # real_dx/dy represents how much the RAW image is shifted relative to CLEAN
        real_dx, real_dy = int(self.off_x * scale), int(self.off_y * scale)
        
        threading.Thread(target=self.chop_thread, args=(real_dx, real_dy), daemon=True).start()

    def chop_thread(self, dx, dy):
        folder = os.path.join(OUTPUT_BASE, self.design_name)
        os.makedirs(folder, exist_ok=True)
        
        arr_c, arr_r = np.array(self.img_clean), np.array(self.img_raw)
        h, w, _ = arr_c.shape

        # --- OVERLAP LOGIC ---
        # Calculate the shared rectangle between Clean (0,0,w,h) and Raw (dx,dy,w,h)
        overlap_x_start = max(0, dx)
        overlap_y_start = max(0, dy)
        overlap_x_end = min(w, w + dx)
        overlap_y_end = min(h, h + dy)

        self.write_log(f"Overlap Zone: Y({overlap_y_start}-{overlap_y_end}) X({overlap_x_start}-{overlap_x_end})")

        tiles_y = list(range(overlap_y_start, overlap_y_end - TILE_SIZE + 1, TILE_SIZE))
        tiles_x = list(range(overlap_x_start, overlap_x_end - TILE_SIZE + 1, TILE_SIZE))
        
        total_tiles = len(tiles_y) * len(tiles_x)
        if total_tiles == 0:
            self.write_log("ERROR: No overlap found! Check alignment.")
            self.is_processing = False
            self.btn_save.config(state=tk.NORMAL, text="CHOP OVERLAP (Enter)")
            return

        count, step = 0, 0
        for y in tiles_y:
            for x in tiles_x:
                # Clean Map Slice
                t_clean = arr_c[y:y+TILE_SIZE, x:x+TILE_SIZE]
                
                # Raw Art Slice (Compensate for shift)
                ry, rx = y - dy, x - dx
                t_raw = arr_r[ry:ry+TILE_SIZE, rx:rx+TILE_SIZE]

                # Only save if there is content (not solid black)
                if np.mean(t_clean) > 2:
                    combined = np.concatenate((t_clean, t_raw), axis=1)
                    Image.fromarray(combined).save(os.path.join(folder, f"tile_{count}.png"))
                    count += 1
                
                step += 1
                if step % 5 == 0:
                    self.progress['value'] = (step / total_tiles) * 100
                    self.root.update_idletasks()

        self.write_log(f"Success: {count} valid overlap tiles saved.")
        self.next_design()

    def next_design(self):
        self.is_processing = False
        self.btn_save.config(state=tk.NORMAL, text="CHOP OVERLAP (Enter)")
        self.progress['value'] = 0
        self.current_idx += 1
        self.off_x, self.off_y = 0, 0
        self.root.after(10, self.load_images)

if __name__ == "__main__":
    files = [f for f in os.listdir(CLEAN_DIR) if f.endswith('.png')]
    root = tk.Tk()
    AlignmentGUI(root, files)
    root.mainloop()