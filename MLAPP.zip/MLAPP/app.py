import os
import re
import numpy as np
from PIL import Image
from psd_tools import PSDImage
import tifffile
import tkinter as tk
from tkinter import messagebox
import threading

# --- CONFIGURATION ---
ORIG_KEYS = ["original", "origin", "raw", "source", "master"]
SEP_KEYS  = ["separation", "separat", "seperat", "refined", "screen", "tech"]
RGB_BLOCK = ["red", "green", "blue", "rgb", "composite", "preview"]

def sanitize_filename(name):
    return re.sub(r'[\\/*?:"<>|]', "", str(name)).strip()

def is_strictly_bitonal(array, gray_tolerance=0.01):
    """
    Checks if the array is purely black and white.
    Drops the screen if more than 'gray_tolerance' % of pixels are gray.
    """
    total_pixels = array.size
    # Count pixels that are NOT 0 and NOT 255
    gray_pixels = np.count_nonzero((array > 0) & (array < 255))
    gray_ratio = gray_pixels / total_pixels
    
    # Return True if it's clean (mostly 0s and 255s)
    return gray_ratio <= gray_tolerance

def process_and_save_array(data_array, target_path):
    try:
        if len(data_array.shape) == 3:
            data_array = data_array[:, :, 0]

        img_float = data_array.astype(float)
        max_val, min_val = np.max(img_float), np.min(img_float)
        
        if max_val - min_val < 0.001: return False

        # Normalize 0-255
        normalized = (img_float - min_val) * (255.0 / (max_val - min_val))
        
        # Invert if background is white
        if np.mean(normalized) > 127:
            normalized = 255 - normalized
            
        # --- NEW LOGIC: DROP IF GRAYSCALE ---
        # We round the pixels to check for "true" colors
        check_array = np.round(normalized).astype('uint8')
        if not is_strictly_bitonal(check_array):
            return False # Discard screen with gray pixels

        img = Image.fromarray(check_array)
        if np.mean(np.array(img)) > 0.05:
            img.save(target_path)
            return True
        return False
    except:
        return False

# --- ENGINES ---

def extract_tiff_brute_force(filepath, target_dir):
    count = 0
    try:
        with tifffile.TiffFile(filepath) as tif:
            for i, page in enumerate(tif.pages):
                tag_name = page.tags.get(285) or page.tags.get(270)
                name_val = str(tag_name.value).lower() if tag_name else f"layer_{i}"
                
                # Skip known RGB previews
                if len(tif.pages) > 3 and any(rgb in name_val for rgb in RGB_BLOCK):
                    continue

                data = page.asarray()
                # Deep scan interleaved channels
                if len(data.shape) == 3 and data.shape[2] > 1:
                    for c in range(data.shape[2]):
                        if process_and_save_array(data[:, :, c], os.path.join(target_dir, f"p{i}_c{c}_{name_val}.png")):
                            count += 1
                else:
                    if process_and_save_array(data, os.path.join(target_dir, f"p{i}_{name_val}.png")):
                        count += 1
        return count
    except: return 0

def extract_psd_all_channels(filepath, target_dir):
    count = 0
    try:
        psd = PSDImage.open(filepath)
        all_channels_data = psd._record.image_data.get_data(psd._record.header)
        for i, channel_bytes in enumerate(all_channels_data):
            img_np = np.frombuffer(channel_bytes, dtype=np.uint8).reshape((psd.height, psd.width))
            if process_and_save_array(img_np, os.path.join(target_dir, f"chan_{i}.png")):
                count += 1
        return count
    except: return 0

# --- DISCOVERY LOGIC ---

def find_best_files(artwork_folder):
    all_files = []
    for root, _, files in os.walk(artwork_folder):
        if any(x in root for x in ["__MACOSX", ".DS_Store"]): continue
        for f in files: all_files.append(os.path.join(root, f))
    
    best_orig, best_sep = {"path": None, "score": -1}, {"path": None, "score": -1}
    for f_path in all_files:
        name, ext = os.path.basename(f_path).lower(), os.path.splitext(f_path)[1].lower()
        # Original (TIF Priority)
        o_score = 60 if any(k in f_path.lower() for k in ORIG_KEYS) else 0
        o_score += 30 if ext in ['.tif', '.tiff'] else 10
        if o_score > best_orig["score"]: best_orig = {"path": f_path, "score": o_score}
        # Separation (PSD Priority)
        s_score = 100 if ext == '.psd' else 0
        if any(k in f_path.lower() for k in ORIG_KEYS): s_score -= 150
        if any(k in f_path.lower() for k in SEP_KEYS): s_score += 50
        if s_score > best_sep["score"]: best_sep = {"path": f_path, "score": s_score}
    return best_orig["path"], best_sep["path"]

# --- GUI ---

class RipApp:
    def __init__(self, root):
        self.root = root
        self.root.title("RIP Automation v13.0 - Bitonal Only")
        self.root.geometry("800x600")
        self.root.configure(bg="#121212")
        tk.Label(root, text="RIP DEEP EXTRACTION (B&W ONLY)", font=("Arial", 14, "bold"), fg="#00FFCC", bg="#121212").pack(pady=20)
        self.log_box = tk.Text(root, height=22, width=90, bg="#1a1a1a", fg="#00FF00", font=("Consolas", 9))
        self.log_box.pack(pady=5, padx=20)
        self.btn = tk.Button(root, text="START PROCESSING", bg="#333", fg="white", font=("Arial", 10, "bold"), command=self.start_thread, height=2, width=30)
        self.btn.pack(pady=20)

    def log(self, msg):
        self.log_box.insert(tk.END, f"> {msg}\n"); self.log_box.see(tk.END); self.root.update_idletasks()

    def start_thread(self):
        self.btn.config(state=tk.DISABLED); threading.Thread(target=self.run, daemon=True).start()

    def run(self):
        base, raw_dir, screen_dir = "Artworks", "input_raw", "output_screens"
        for d in [raw_dir, screen_dir]: os.makedirs(d, exist_ok=True)
        folders = [f for f in os.listdir(base) if os.path.isdir(os.path.join(base, f)) and not f.startswith('.')]
        
        for folder in folders:
            self.log(f"📁 Folder: {folder}")
            orig, sep = find_best_files(os.path.join(base, folder))
            
            if orig:
                try:
                    with Image.open(orig) as img:
                        img.seek(0); img.convert("RGB").save(os.path.join(raw_dir, f"{folder}.png"))
                    self.log(f"  ✅ Original extracted")
                except: pass
            
            if sep:
                target = os.path.join(screen_dir, folder); os.makedirs(target, exist_ok=True)
                n = extract_psd_all_channels(sep, target) if sep.lower().endswith('.psd') else extract_tiff_brute_force(sep, target)
                self.log(f"  ✅ Screens: {n} valid B&W screens found.")
            else: self.log("  ⚠️ No separation file.")

        self.log("\nFINISHED."); self.btn.config(state=tk.NORMAL)
        messagebox.showinfo("Done", "Bitonal extraction complete.")

if __name__ == "__main__":
    root = tk.Tk(); app = RipApp(root); root.mainloop()