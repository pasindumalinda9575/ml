import os
import numpy as np
from PIL import Image, ImageOps
from psd_tools import PSDImage

def separate_by_folder_structure(input_dir="input_raw", output_base="separated_screens"):
    if not os.path.exists(input_dir):
        print(f"Directory {input_dir} not found.")
        return

    # 1. Iterate through artwork folders (e.g., "Photoreal fruits")
    for artwork_name in os.listdir(input_dir):
        artwork_path = os.path.join(input_dir, artwork_name)
        
        if not os.path.isdir(artwork_path):
            continue
            
        print(f"\n--- Processing Artwork Folder: {artwork_name} ---")
        
        psd_files = [f for f in os.listdir(artwork_path) if f.lower().endswith('.psd')]
        
        # Identify the two source files
        original_file = next((f for f in psd_files if "original" in f.lower()), None)
        technician_file = next((f for f in psd_files if "original" not in f.lower()), None)

        if not original_file or not technician_file:
            print(f"  [SKIP] Folder {artwork_name} must contain one 'Original' and one 'Technician' PSD.")
            continue

        try:
            # --- PART A: GET ARTWORK FROM ORIGINAL PSD ---
            raw_png_path = os.path.join(input_dir, f"{artwork_name}.png")
            
            # Avoid context manager 'with' to prevent protocol error
            psd_art = PSDImage.open(os.path.join(artwork_path, original_file))
            
            # Use topil() or composite() on the Original (usually RGB/CMYK)
            try:
                artwork = psd_art.composite().convert("RGB")
                artwork.save(raw_png_path)
                print(f"  [RAW] Saved color artwork: {artwork_name}.png")
            except:
                # Fallback if composite fails on original
                psd_art.topil().convert("RGB").save(raw_png_path)
                print(f"  [RAW] Saved artwork via topil fallback.")

            # --- PART B: EXTRACT SCREENS FROM TECHNICIAN PSD ---
            output_folder = os.path.join(output_base, artwork_name)
            os.makedirs(output_folder, exist_ok=True)

            psd_sep = PSDImage.open(os.path.join(artwork_path, technician_file))
            num_channels = psd_sep._record.header.channels
            print(f"  [SCREENS] Deep extracting {num_channels} channels from technician file.")

            count = 0
            for i in range(num_channels):
                try:
                    # YOUR SUCCESSFUL LOGIC: Low-level image_data access
                    channel_data = psd_sep._record.image_data.get_data(psd_sep._record.header, i)
                    
                    # Convert raw bytes to PIL
                    img_chan = Image.frombytes('L', (psd_sep.width, psd_sep.height), channel_data, 'raw', 'L')
                    
                    # Invert: Black ink -> White on Black mask for training
                    inverted = ImageOps.invert(img_chan)
                    
                    # Statistical check to skip empty channels
                    if np.mean(np.array(inverted)) > 0.1:
                        save_path = os.path.join(output_folder, f"screen_{count}.png")
                        inverted.save(save_path)
                        print(f"    + Saved Screen {count}")
                        count += 1
                except Exception as e:
                    # Fallback to topil(channel=i) if binary data fails
                    try:
                        chan_img = psd_sep.topil(channel=i)
                        if chan_img:
                            ImageOps.invert(chan_img.convert("L")).save(os.path.join(output_folder, f"screen_{count}.png"))
                            count += 1
                    except:
                        continue
            
            print(f"  [DONE] Finished {artwork_name} ({count} screens).")

        except Exception as e:
            print(f"  [ERROR] Processing {artwork_name} failed: {e}")

if __name__ == "__main__":
    separate_by_folder_structure()

