import os
import numpy as np
from PIL import Image, ImageOps
from psd_tools import PSDImage

def separate_psd_final(input_dir="input_raw", output_base="separated_screens"):
    if not os.path.exists(input_dir): return

    psd_files = [f for f in os.listdir(input_dir) if f.lower().endswith('.psd')]
    
    for filename in psd_files:
        design_name = os.path.splitext(filename)[0]
        psd_path = os.path.join(input_dir, filename)
        
        print(f"--- Deep Extracting PSD: {design_name} ---")
        
        try:
            psd = PSDImage.open(psd_path)
            
            # 1. Save Color Composite
            # Since composite() worked for the preview before, we keep it for the raw file
            raw_png_path = os.path.join(input_dir, f"{design_name}.png")
            psd.composite().convert("RGB").save(raw_png_path)
            print(f"  [RAW] Saved color composite.")

            # 2. Extract Screens
            output_folder = os.path.join(output_base, design_name)
            os.makedirs(output_folder, exist_ok=True)

            # Get the raw channel count from the header record
            num_channels = psd._record.header.channels
            print(f"  [SCREENS] Header confirms {num_channels} channels.")

            count = 0
            for i in range(num_channels):
                try:
                    # We use the internal 'topil' logic but through the low-level 
                    # image_data record. This is the only way to get data out 
                    # of a flat multichannel file.
                    channel_data = psd._record.image_data.get_data(psd._record.header, i)
                    
                    # Convert raw bytes to a PIL image
                    # For Multichannel, data is usually 8-bit grayscale ('L')
                    img_chan = Image.frombytes('L', (psd.width, psd.height), channel_data, 'raw', 'L')
                    
                    # Training Inversion: Black ink -> White on Black mask
                    inverted = ImageOps.invert(img_chan)
                    
                    # Statistical check to ensure it's not a blank channel
                    if np.mean(np.array(inverted)) > 0.1:
                        save_path = os.path.join(output_folder, f"screen_{count}.png")
                        inverted.save(save_path)
                        print(f"    + Extracted Screen {count}")
                        count += 1
                except Exception as e:
                    # Fallback: Try the topil helper directly if the record access fails
                    try:
                        chan_img = psd.topil(channel=i)
                        if chan_img:
                            ImageOps.invert(chan_img.convert("L")).save(os.path.join(output_folder, f"screen_{count}.png"))
                            count += 1
                    except:
                        continue
            
            print(f"  [DONE] Total: {count} screens extracted.")

        except Exception as e:
            print(f"  [ERROR] {e}")

if __name__ == "__main__":
    separate_psd_final()