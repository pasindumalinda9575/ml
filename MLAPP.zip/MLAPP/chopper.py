import os
import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
import numpy as np
import threading

# --- CONFIGURATION ---
TILE_SIZE = 256
CLEAN_DIR = "input_cleaned"
RAW_DIR = "input_raw"
OUTPUT_BASE = "training_tiles"

class AlignmentGUI:
    def __init__(self, root, file_list):
        self.root = root
        self.file_list = file_list
        self.current_idx = 0
        self.off_x, self.off_y = 0, 0
        self.is_processing = False
        
        self.root.title("Pixel-Sync: Dataset Builder + Captions")
        self.root.geometry("1200x950")
        self.root.configure(bg="#1e1e1e")

        # Layout
        self.canvas = tk.Canvas(root, width=800, height=800, bg="#000000", highlightthickness=0)
        self.canvas.pack(side=tk.LEFT, padx=20, pady=20)

        self.sidebar = tk.Frame(root, width=350, bg="#1e1e1e")
        self.sidebar.pack(side=tk.RIGHT, fill=tk.Y, padx=20)

        # Header
        tk.Label(self.sidebar, text="DATASET BUILDER", font=("Segoe UI", 16, "bold"), fg="#4CAF50", bg="#1e1e1e").pack(pady=10)
        
        # --- CAPTION BOX SECTION ---
        tk.Label(self.sidebar, text="TRAINING CAPTION (PROMPT):", font=("Segoe UI", 9, "bold"), fg="#3498db", bg="#1e1e1e").pack(anchor="w", pady=(10, 0))
        self.caption_box = tk.Text(self.sidebar, height=4, width=40, bg="#252525", fg="white", font=("Arial", 10), insertbackground="white")
        self.caption_box.pack(pady=5)
        self.caption_box.insert(tk.END, "a rip-logic style pair, left side is a flat semantic map, right side is the halftone screen separation")

        # Nudge Controls
        tk.Label(self.sidebar, text="ALIGNMENT NUDGE", font=("Segoe UI", 9), fg="#888", bg="#1e1e1e").pack(pady=(10, 0))
        ctrl_frame = tk.Frame(self.sidebar, bg="#1e1e1e")
        ctrl_frame.pack(pady=5)
        
        btn_opts = {"width": 5, "height": 2, "font": ("Arial", 10, "bold"), "bg": "#333", "fg": "white", "activebackground": "#555"}
        tk.Button(ctrl_frame, text="▲", **btn_opts, command=lambda: self.nudge(0, -1)).grid(row=0, column=1, pady=2)
        tk.Button(ctrl_frame, text="◀", **btn_opts, command=lambda: self.nudge(-1, 0)).grid(row=1, column=0, padx=2)
        tk.Button(ctrl_frame, text="▶", **btn_opts, command=lambda: self.nudge(1, 0)).grid(row=1, column=2, padx=2)
        tk.Button(ctrl_frame, text="▼", **btn_opts, command=lambda: self.nudge(0, 1)).grid(row=2, column=1, pady=2)

        self.offset_txt = tk.Label(self.sidebar, text="X: 0 | Y: 0", font=("Consolas", 12), fg="#00ff00", bg="#1e1e1e")
        self.offset_txt.pack(pady=5)

        # Action Buttons
        tk.Button(self.sidebar, text="Reset Alignment (R)", bg="#444", fg="white", command=self.reset_offset).pack(fill=tk.X, pady=5)
        
        self.btn_chop = tk.Button(self.sidebar, text="GENERATE TILES & NEXT", bg="#2e7d32", fg="white", 
                                  font=("Arial", 11, "bold"), height=3, command=self.start_process)
        self.btn_chop.pack(fill=tk.X, pady=20)

        tk.Button(self.sidebar, text="SKIP", bg="#c62828", fg="white", command=self.skip).pack(fill=tk.X)

        # Progress
        self.progress = ttk.Progressbar(self.sidebar, orient=tk.HORIZONTAL, length=200, mode='determinate')
        self.progress.pack(pady=20, fill=tk.X)

        # Console
        self.log = tk.Text(self.sidebar, height=8, width=40, bg="#000", fg="#00ff00", font=("Consolas", 8))
        self.log.pack(pady=10)

        # Keybinds
        self.root.bind("<Up>", lambda e: self.nudge(0, -1))
        self.root.bind("<Down>", lambda e: self.nudge(0, 1))
        self.root.bind("<Left>", lambda e: self.nudge(-1, 0))
        self.root.bind("<Right>", lambda e: self.nudge(1, 0))
        self.root.bind("<Return>", lambda e: self.start_process())
        self.root.bind("r", lambda e: self.reset_offset())

        self.load_artwork()

    def log_msg(self, msg):
        self.log.insert(tk.END, f"> {msg}\n")
        self.log.see(tk.END)

    def nudge(self, dx, dy):
        if self.is_processing: return
        self.off_x += dx
        self.off_y += dy
        self.update_view()

    def reset_offset(self):
        self.off_x = self.off_y = 0
        self.update_view()

    def load_artwork(self):
        if self.current_idx >= len(self.file_list):
            self.log_msg("QUEUE FINISHED.")
            return

        fname = self.file_list[self.current_idx]
        self.design_name = os.path.splitext(fname)[0]
        self.log_msg(f"Loading: {self.design_name}")
        
        # Update Caption Box with Design Name automatically
        default_cap = f"a rip-logic style pair of {self.design_name.replace('_', ' ')}, left side is a flat semantic map, right side is the halftone screen separation"
        self.caption_box.delete("1.0", tk.END)
        self.caption_box.insert(tk.END, default_cap)

        self.img_clean = Image.open(os.path.join(CLEAN_DIR, fname)).convert("RGB")
        self.img_raw = Image.open(os.path.join(RAW_DIR, f"{self.design_name}.png")).convert("RGB")
        
        self.prev_clean = self.img_clean.resize((800, 800), Image.NEAREST)
        self.prev_raw = self.img_raw.resize((800, 800), Image.NEAREST)
        self.update_view()

    def update_view(self):
        base = self.prev_clean.copy()
        top = Image.new("RGB", (800, 800), (0, 0, 0))
        top.paste(self.prev_raw, (self.off_x, self.off_y))
        
        blended = Image.blend(base, top, alpha=0.5)
        self.tk_img = ImageTk.PhotoImage(blended)
        self.canvas.delete("all")
        self.canvas.create_image(400, 400, image=self.tk_img)
        self.offset_txt.config(text=f"X: {self.off_x} | Y: {self.off_y}")

    def skip(self):
        self.current_idx += 1
        self.reset_offset()
        self.load_artwork()

    def start_process(self):
        if self.is_processing: return
        self.is_processing = True
        self.btn_chop.config(state=tk.DISABLED)
        
        # Capture current caption from UI
        user_caption = self.caption_box.get("1.0", tk.END).strip()
        
        scale = self.img_clean.width / 800
        dx, dy = int(self.off_x * scale), int(self.off_y * scale)
        
        threading.Thread(target=self.run_chop, args=(dx, dy, user_caption), daemon=True).start()

    def run_chop(self, dx, dy, final_caption):
        out_dir = os.path.join(OUTPUT_BASE, self.design_name)
        os.makedirs(out_dir, exist_ok=True)
        
        c_arr = np.array(self.img_clean)
        r_arr = np.array(self.img_raw)
        h, w, _ = c_arr.shape

        ox_start, ox_end = max(0, dx), min(w, w + dx)
        oy_start, oy_end = max(0, dy), min(h, h + dy)

        rows = range(oy_start, oy_end - TILE_SIZE + 1, TILE_SIZE)
        cols = range(ox_start, ox_end - TILE_SIZE + 1, TILE_SIZE)
        
        count = 0
        for i, y in enumerate(rows):
            for x in cols:
                tile_c = c_arr[y : y+TILE_SIZE, x : x+TILE_SIZE]
                ry, rx = y - dy, x - dx
                tile_r = r_arr[ry : ry+TILE_SIZE, rx : rx+TILE_SIZE]

                # Only save if there is content (not just empty background)
                if np.mean(tile_c) > 3:
                    combined = np.concatenate((tile_r, tile_c), axis=1)
                    base_name = f"tile_{self.design_name}_{count}"
                    
                    # Save Pair
                    Image.fromarray(combined).save(os.path.join(out_dir, f"{base_name}.png"))
                    
                    # Save specific caption file for Kohya
                    with open(os.path.join(out_dir, f"{base_name}.txt"), "w") as f:
                        f.write(final_caption)
                        
                    count += 1
            
            self.progress['value'] = ((i + 1) / len(rows)) * 100
            self.root.update_idletasks()

        self.log_msg(f"Finished: {count} tiles with captions.")
        self.is_processing = False
        self.btn_chop.config(state=tk.NORMAL)
        self.current_idx += 1
        self.off_x = self.off_y = 0
        self.progress['value'] = 0
        self.root.after(10, self.load_artwork)

if __name__ == "__main__":
    if not os.path.exists(CLEAN_DIR): os.makedirs(CLEAN_DIR)
    if not os.path.exists(RAW_DIR): os.makedirs(RAW_DIR)
    files = [f for f in os.listdir(CLEAN_DIR) if f.lower().endswith('.png')]
    root = tk.Tk()
    app = AlignmentGUI(root, files)
    root.mainloop()