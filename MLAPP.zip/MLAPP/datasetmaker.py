import os
import shutil
import random

def prepare_dataset(src_root="training_tiles", dest_root="ready_for_ai", split_ratio=0.9, repeats=20):
    # Kohya Directory Structure
    train_img_dir = os.path.join(dest_root, "img", f"{repeats}_riplogic")
    val_dir = os.path.join(dest_root, "val_holdout") 
    
    # Clean old data
    if os.path.exists(dest_root):
        shutil.rmtree(dest_root)
        
    os.makedirs(train_img_dir, exist_ok=True)
    os.makedirs(val_dir, exist_ok=True)

    all_pairs = []

    if not os.path.exists(src_root):
        print(f"Error: {src_root} not found!")
        return

    # 1. Collect pairs
    for artwork_folder in os.listdir(src_root):
        folder_path = os.path.join(src_root, artwork_folder)
        if not os.path.isdir(folder_path): continue
        
        for file in os.listdir(folder_path):
            if file.endswith(".png"):
                base_name = os.path.splitext(file)[0]
                img_path = os.path.join(folder_path, file)
                txt_path = os.path.join(folder_path, f"{base_name}.txt")
                
                if os.path.exists(txt_path):
                    # FIX: Prevent "photoreal_fruits_photoreal_fruits_0.png"
                    # If the filename already starts with the folder name, don't add it again
                    if base_name.startswith(artwork_folder):
                        unique_name = base_name
                    else:
                        unique_name = f"{artwork_folder}_{base_name}"
                        
                    all_pairs.append((img_path, txt_path, unique_name))

    # 2. Shuffle and Split
    random.seed(42) 
    random.shuffle(all_pairs)
    split_idx = int(len(all_pairs) * split_ratio)
    train_set = all_pairs[:split_idx]
    val_set = all_pairs[split_idx:]

    # 3. Copy files (Both PNG and TXT)
    print(f"📦 Moving {len(train_set)} pairs (Images + Text) to Kohya folder...")
    for img_p, txt_p, new_n in train_set:
        shutil.copy2(img_p, os.path.join(train_img_dir, f"{new_n}.png"))
        shutil.copy2(txt_p, os.path.join(train_img_dir, f"{new_n}.txt"))
        
    print(f"🧪 Moving {len(val_set)} pairs to Holdout folder...")
    for img_p, txt_p, new_n in val_set:
        shutil.copy2(img_p, os.path.join(val_dir, f"{new_n}.png"))
        shutil.copy2(txt_p, os.path.join(val_dir, f"{new_n}.txt"))

    print("\n" + "="*50)
    print("SUCCESS: Naming fixed and Text files included.")
    print(f"Verify one pair: {os.listdir(train_img_dir)[0]} and {os.listdir(train_img_dir)[1]}")
    print("="*50)

if __name__ == "__main__":
    prepare_dataset()