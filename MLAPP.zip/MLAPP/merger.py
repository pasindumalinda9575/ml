import os
import tkinter as tk
import customtkinter as ctk
from tkinter import messagebox
from PIL import Image, ImageTk
import numpy as np
import json
import random
from collections import deque

ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")

class RIPMergerModern:
    def __init__(self, root):
        self.root = root
        self.root.title("RIP MERGER PRO v3.0 - Reset & Stability")
        self.root.geometry("1450x900")

        # --- PATHS ---
        self.raw_dir = "input_raw"
        self.screens_base = "output_screens"
        self.out_dir = "input_cleaned"
        self.session_file = "session_state.json"
        
        # --- STATE ---
        self.artwork_list = [f.replace('.png', '') for f in os.listdir(self.raw_dir) if f.endswith('.png')]
        self.current_art_index = 0
        self.screens = [] 
        self.selected_screen_index = 0
        self.zoom = 0.15
        self.off_x, self.off_y = 50, 50
        self.history = deque(maxlen=6) 

        self.setup_ui()
        if self.artwork_list:
            self.load_artwork()

    def get_truly_random_color(self):
        return [random.randint(0, 255), random.randint(50, 255), random.randint(50, 255)]

    def setup_ui(self):
        self.root.grid_columnconfigure(1, weight=1)
        self.root.grid_rowconfigure(0, weight=1)

        # --- SIDEBAR ---
        self.sidebar = ctk.CTkFrame(self.root, width=380, corner_radius=0)
        self.sidebar.grid(row=0, column=0, sticky="nsew")
        
        header = ctk.CTkFrame(self.sidebar, fg_color="transparent")
        header.pack(fill="x", pady=10)
        ctk.CTkLabel(header, text="LAYERS", font=ctk.CTkFont(size=18, weight="bold")).pack(side="left", padx=20)
        ctk.CTkButton(header, text="⟲ Undo", width=60, fg_color="#e67e22", command=self.undo).pack(side="right", padx=5)
        
        self.can_single = tk.Canvas(self.sidebar, width=200, height=200, bg="black", highlightthickness=0)
        self.can_single.pack(pady=5)

        # Control Buttons
        ctrl_frame = ctk.CTkFrame(self.sidebar, fg_color="transparent")
        ctrl_frame.pack(fill="x", padx=10, pady=5)
        
        ctk.CTkButton(ctrl_frame, text="+ BG Layer", fg_color="#8e44ad", width=160, command=self.force_add_bg).pack(side="left", padx=5)
        ctk.CTkButton(ctrl_frame, text="⚠ Reset Art", fg_color="#c0392b", hover_color="#a93226", width=160, command=self.reset_artwork).pack(side="right", padx=5)
        
        self.scroll_frame = ctk.CTkScrollableFrame(self.sidebar, label_text="Layer Stack")
        self.scroll_frame.pack(fill="both", expand=True, padx=10, pady=10)

        btn_row = ctk.CTkFrame(self.sidebar, fg_color="transparent")
        btn_row.pack(fill="x", padx=10, pady=10)
        ctk.CTkButton(btn_row, text="▲ Move Up", width=150, command=lambda: self.move_screen(-1)).pack(side="left", expand=True, padx=2)
        ctk.CTkButton(btn_row, text="▼ Move Down", width=150, command=lambda: self.move_screen(1)).pack(side="left", expand=True, padx=2)

        # --- MAIN VIEW ---
        self.main_view = ctk.CTkFrame(self.root, corner_radius=0, fg_color="#101010")
        self.main_view.grid(row=0, column=1, sticky="nsew")
        
        self.top_bar = ctk.CTkFrame(self.main_view, height=50, corner_radius=0)
        self.top_bar.pack(fill="x", side="top")
        
        ctk.CTkButton(self.top_bar, text="<< Prev", width=80, command=self.prev_art).pack(side="left", padx=10)
        self.lbl_art = ctk.CTkLabel(self.top_bar, text="", font=("Arial", 12, "bold"))
        self.lbl_art.pack(side="left", padx=15)
        ctk.CTkButton(self.top_bar, text="Next >>", width=80, command=self.next_art).pack(side="left", padx=10)
        ctk.CTkButton(self.top_bar, text="EXPORT FINAL PNG", fg_color="#27ae60", command=self.save_final).pack(side="right", padx=15)

        self.canvas = tk.Canvas(self.main_view, bg="#0a0a0a", highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)
        self.canvas.bind("<MouseWheel>", self.handle_zoom)
        self.canvas.bind("<ButtonPress-3>", self.start_pan)
        self.canvas.bind("<B3-Motion>", self.handle_pan)
        self.canvas.bind("<Button-1>", self.sample_color)

    def reset_artwork(self):
        """Clears the session data for the current art and reloads it from scratch."""
        name = self.artwork_list[self.current_art_index]
        if messagebox.askyesno("Reset", f"Discard all changes for {name} and restore defaults?"):
            if os.path.exists(self.session_file):
                try:
                    with open(self.session_file, "r") as f:
                        data = json.load(f)
                    if name in data:
                        del data[name]
                    with open(self.session_file, "w") as f:
                        json.dump(data, f)
                except Exception as e:
                    print(f"Reset Error: {e}")
            
            self.load_artwork()
            messagebox.showinfo("Reset Complete", "Artwork has been restored to default.")

    def load_artwork(self):
        name = self.artwork_list[self.current_art_index]
        self.lbl_art.configure(text=f"Editing: {name}")
        self.img_raw = Image.open(os.path.join(self.raw_dir, name + ".png")).convert('RGB')
        
        screen_path = os.path.join(self.screens_base, name)
        temp_screens = []
        
        if os.path.exists(screen_path):
            files = sorted([f for f in os.listdir(screen_path) if f.endswith('.png')])
            for f in files:
                mask = np.array(Image.open(os.path.join(screen_path, f)).convert("L"))
                vis_var = tk.BooleanVar(value=True)
                temp_screens.append({'name': f, 'mask': mask, 'color': self.get_truly_random_color(), 'visible': vis_var, 'is_bg': False})
        
        session_data = self.load_session(name)
        if session_data:
            ordered = []
            for item in session_data:
                match = next((x for x in temp_screens if x['name'] == item['name']), None)
                if not match and item.get('is_bg'): 
                    vis_var = tk.BooleanVar(value=item.get('visible', False))
                    match = {'name': item['name'], 'mask': None, 'color': item['color'], 'visible': vis_var, 'is_bg': True}
                
                if match:
                    match['color'] = item['color']
                    match['visible'].set(item.get('visible', True))
                    ordered.append(match)
            self.screens = ordered
        else:
            self.screens = temp_screens 
            self.force_add_bg(auto=True) 

        self.history.clear()
        self.push_history()
        self.selected_screen_index = 0
        self.refresh_layer_list()
        self.render()

    def force_add_bg(self, auto=False):
        if any(s.get('is_bg') for s in self.screens): return
        bg_vis = tk.BooleanVar(value=False)
        bg_layer = {'name': "SOLID BACKGROUND", 'mask': None, 'color': [255,255,255], 'visible': bg_vis, 'is_bg': True}
        self.screens.insert(0, bg_layer)
        if not auto: 
            self.on_change_action()

    def move_screen(self, d):
        i = self.selected_screen_index
        if 0 <= i + d < len(self.screens):
            self.screens[i], self.screens[i+d] = self.screens[i+d], self.screens[i]
            self.selected_screen_index = i + d
            self.on_change_action()

    def refresh_layer_list(self):
        for w in self.scroll_frame.winfo_children(): w.destroy()
        for i, s in enumerate(self.screens):
            is_sel = (i == self.selected_screen_index)
            row_bg = "#3498db" if is_sel else ("#1a1a1a" if s['is_bg'] else "#2b2b2b")
            color_hex = '#%02x%02x%02x' % tuple(s['color'])
            
            frame = ctk.CTkFrame(self.scroll_frame, fg_color=row_bg)
            frame.pack(fill="x", pady=1)
            
            ctk.CTkCheckBox(frame, text="", variable=s['visible'], command=self.on_change_action, width=20).pack(side="left", padx=5)
            ctk.CTkFrame(frame, width=14, height=14, fg_color=color_hex, corner_radius=7).pack(side="left", padx=5)
            
            text_frame = tk.Frame(frame, bg=row_bg)
            text_frame.pack(side="left", fill="x", expand=True, padx=5)
            name_text = f"★ {s['name']}" if s['is_bg'] else s['name']
            
            l1 = tk.Label(text_frame, text=name_text, fg="white", bg=row_bg, font=("Arial", 9, "bold"), anchor="w")
            l1.pack(fill="x")
            l2 = tk.Label(text_frame, text=f"RGB: {s['color']}", fg="#00FFCC" if is_sel else "#888", bg=row_bg, font=("Consolas", 8), anchor="w")
            l2.pack(fill="x")

            for w_child in [frame, text_frame, l1, l2]:
                w_child.bind("<Button-1>", lambda e, idx=i: self.select_screen(idx))

    def select_screen(self, idx):
        self.selected_screen_index = idx
        self.refresh_layer_list()
        self.render()

    def on_change_action(self):
        self.push_history()
        self.save_session()
        self.refresh_layer_list()
        self.render()

    def push_history(self):
        snap = []
        for s in self.screens:
            snap.append({'name': s['name'], 'color': list(s['color']), 'visible': s['visible'].get(), 'is_bg': s.get('is_bg')})
        self.history.append(snap)

    def undo(self):
        if len(self.history) <= 1: return
        self.history.pop()
        last = self.history[-1]
        reordered = []
        for saved in last:
            match = next((x for x in self.screens if x['name'] == saved['name']), None)
            if not match and saved['is_bg']:
                match = {'name': saved['name'], 'mask': None, 'color': saved['color'], 'visible': tk.BooleanVar(), 'is_bg': True}
            if match:
                match['color'] = saved['color']
                match['visible'].set(saved['visible'])
                reordered.append(match)
        self.screens = reordered
        self.refresh_layer_list(); self.render()

    def sample_color(self, event):
        w_mid = self.canvas.winfo_width() // 2
        if event.x > w_mid: return 
        rx = int((event.x - self.off_x) / self.zoom)
        ry = int((event.y - self.off_y) / self.zoom)
        if 0 <= rx < self.img_raw.width and 0 <= ry < self.img_raw.height:
            self.screens[self.selected_screen_index]['color'] = list(self.img_raw.getpixel((rx, ry)))
            self.on_change_action()

    def render(self):
        if not self.screens: return
        ref_mask = next((s['mask'] for s in self.screens if s['mask'] is not None), None)
        h, w = ref_mask.shape if ref_mask is not None else (1000, 1000)
        
        merged = np.zeros((h, w, 3), dtype=np.uint8)
        for s in self.screens:
            if not s['visible'].get(): continue
            if s['is_bg']: merged[:, :] = s['color']
            else: merged[s['mask'] > 127] = s['color']
        
        vw, vh = int(w * self.zoom), int(h * self.zoom)
        w_mid = self.canvas.winfo_width() // 2
        self.tk_raw = ImageTk.PhotoImage(self.img_raw.resize((vw, vh), Image.NEAREST))
        self.tk_mrg = ImageTk.PhotoImage(Image.fromarray(merged).resize((vw, vh), Image.NEAREST))
        self.canvas.delete("all")
        self.canvas.create_image(self.off_x, self.off_y, anchor="nw", image=self.tk_raw)
        self.canvas.create_image(w_mid + self.off_x, self.off_y, anchor="nw", image=self.tk_mrg)

        # Mini preview update
        sel = self.screens[self.selected_screen_index]
        p_img = Image.new("RGB", (200, 200), tuple(sel['color'])) if sel['is_bg'] else \
                Image.fromarray(sel['mask']).resize((200, 200), Image.NEAREST)
        self.tk_single = ImageTk.PhotoImage(p_img)
        self.can_single.delete("all"); self.can_single.create_image(100, 100, image=self.tk_single)

    def save_session(self):
        name = self.artwork_list[self.current_art_index]
        state = {name: [{'name': s['name'], 'color': s['color'], 'visible': s['visible'].get(), 'is_bg': s.get('is_bg')} for s in self.screens]}
        if os.path.exists(self.session_file):
            try:
                with open(self.session_file, "r") as f: d = json.load(f)
                d.update(state); state = d
            except: pass
        with open(self.session_file, "w") as f: json.dump(state, f)

    def load_session(self, art_name):
        if not os.path.exists(self.session_file): return None
        try:
            with open(self.session_file, "r") as f: return json.load(f).get(art_name)
        except: return None

    def save_final(self):
        ref_mask = next((s['mask'] for s in self.screens if s['mask'] is not None), None)
        h, w = ref_mask.shape
        final = np.zeros((h, w, 3), dtype=np.uint8)
        for s in self.screens:
            if s['visible'].get():
                if s['is_bg']: final[:, :] = s['color']
                else: final[s['mask'] > 127] = s['color']
        path = os.path.join(self.out_dir, self.artwork_list[self.current_art_index] + ".png")
        os.makedirs(self.out_dir, exist_ok=True)
        Image.fromarray(final).save(path); messagebox.showinfo("Saved", f"Exported: {path}")

    def handle_zoom(self, e): self.zoom *= 1.1 if e.delta > 0 else 0.9; self.render()
    def start_pan(self, e): self.lx, self.ly = e.x, e.y
    def handle_pan(self, e):
        self.off_x += e.x - self.lx; self.off_y += e.y - self.ly; self.lx, self.ly = e.x, e.y; self.render()

    def prev_art(self): self.current_art_index=(self.current_art_index-1)%len(self.artwork_list); self.load_artwork()
    def next_art(self): self.current_art_index=(self.current_art_index+1)%len(self.artwork_list); self.load_artwork()

if __name__ == "__main__":
    root = ctk.CTk(); app = RIPMergerModern(root); root.mainloop()