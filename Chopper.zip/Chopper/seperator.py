import cv2
import numpy as np
import os, sys, io
from svglib.svglib import svg2rlg
from reportlab.graphics import renderPM
from PIL import Image

# Check for -d argument to skip existing folders
SKIP_EXISTING = "-d" in sys.argv

def separate_batch(input_dir="input_raw", base_output="separated_screens"):
    if not os.path.exists(input_dir):
        print(f"Error: {input_dir} not found.")
        return

    for filename in os.listdir(input_dir):
        design_name = os.path.splitext(filename)[0]
        output_folder = os.path.join(base_output, design_name)
        
        if SKIP_EXISTING and os.path.exists(output_folder):
            print(f"Skipping {design_name} (Directory exists)")
            continue

        image_path = os.path.join(input_dir, filename)
        
        # Load Image / Rasterize SVG
        if filename.lower().endswith('.svg'):
            drawing = svg2rlg(image_path)
            png_data = io.BytesIO()
            renderPM.drawToFile(drawing, png_data, fmt="PNG")
            img = cv2.cvtColor(np.array(Image.open(png_data).convert('RGB')), cv2.COLOR_RGB2BGR)
        else:
            img = cv2.imread(image_path)

        if img is None: continue

        # K-Means Separation
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        pixels = img_rgb.reshape(-1, 3).astype(np.float32)
        _, labels, centers = cv2.kmeans(pixels, 12, None, (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 100, 0.2), 10, cv2.KMEANS_RANDOM_CENTERS)
        
        os.makedirs(output_folder, exist_ok=True)
        counts = np.bincount(labels.flatten())
        bg_idx = np.argmax(counts)

        count = 0
        for i in range(len(centers)):
            if i == bg_idx: continue
            mask = (labels.flatten() == i).reshape(img.shape[0], img.shape[1])
            if np.sum(mask) < (img.shape[0] * img.shape[1] * 0.001): continue
            
            screen = np.zeros((img.shape[0], img.shape[1]), dtype=np.uint8)
            screen[mask] = 255
            cv2.imwrite(os.path.join(output_folder, f"screen_{count}.png"), screen)
            count += 1
        print(f"Done: {design_name} ({count} screens)")

if __name__ == "__main__":
    separate_batch()