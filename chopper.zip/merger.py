# import os, sys
# import numpy as np
# from PIL import Image

# TRAINING_COLORS = [(255,0,0),(0,255,0),(0,0,255),(255,255,0),(255,0,255),(0,255,255),(128,0,0),(0,128,0),(0,0,128),(128,128,0),(128,0,128)]

# def batch_merge(base_folder="separated_screens", output_dir="input_cleaned"):
#     os.makedirs(output_dir, exist_ok=True)
    
#     for design_folder in os.listdir(base_folder):
#         folder_path = os.path.join(base_folder, design_folder)
#         if not os.path.isdir(folder_path): continue
        
#         screens = [f for f in os.listdir(folder_path) if f.endswith('.png')]
        
#         # Skip if fewer than 2 screens
#         if len(screens) < 2:
#             print(f"Skipping {design_folder}: Only {len(screens)} screen(s) found.")
#             continue

#         first = Image.open(os.path.join(folder_path, screens[0])).convert("L")
#         master_map = np.zeros((first.size[1], first.size[0], 3), dtype=np.uint8)

#         for i, s_file in enumerate(sorted(screens)):
#             if i >= len(TRAINING_COLORS): break
#             mask = np.array(Image.open(os.path.join(folder_path, s_file)).convert("L"))
#             master_map[mask > 128] = TRAINING_COLORS[i]

#         Image.fromarray(master_map).save(os.path.join(output_dir, f"{design_folder}.png"))
#         print(f"Merged: {design_folder}")

# if __name__ == "__main__":
#     batch_merge()


import os
import numpy as np
from PIL import Image

# Fixed color palette for the AI to recognize different ink layers
TRAINING_COLORS = [
    (255, 0, 0), (0, 255, 0), (0, 0, 255), (255, 255, 0), 
    (255, 0, 255), (0, 255, 255), (128, 0, 0), (0, 128, 0), 
    (0, 0, 128), (128, 128, 0), (128, 0, 128)
]

def batch_merge(base_folder="separated_screens", output_dir="input_cleaned"):
    # Create the output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)
    
    # Iterate through each design folder (e.g., "Photoreal fruits")
    for design_folder in os.listdir(base_folder):
        folder_path = os.path.join(base_folder, design_folder)
        
        # Ensure we are only looking at directories
        if not os.path.isdir(folder_path):
            continue
            
        # Get all extracted screen PNGs (screen_0.png, screen_1.png, etc.)
        screens = [f for f in os.listdir(folder_path) if f.startswith('screen_') and f.endswith('.png')]
        
        if not screens:
            print(f"Skipping {design_folder}: No screens found.")
            continue

        print(f"Merging {len(screens)} screens for: {design_folder}")

        # Open the first screen to get the correct dimensions
        first_screen = Image.open(os.path.join(folder_path, screens[0]))
        width, height = first_screen.size
        
        # Initialize a black master map (Answer image for the AI)
        master_map = np.zeros((height, width, 3), dtype=np.uint8)

        # Sort screens to ensure screen_0, screen_1, etc. are processed in order
        for i, s_file in enumerate(sorted(screens, key=lambda x: int(x.split('_')[1].split('.')[0]))):
            if i >= len(TRAINING_COLORS):
                print(f"  ! Warning: More screens than available TRAINING_COLORS. Skipping screen {i}+")
                break
                
            # Load screen and convert to grayscale array
            mask = np.array(Image.open(os.path.join(folder_path, s_file)).convert("L"))
            
            # Apply the specific color for this screen index
            # Wherever the mask is white (> 128), we apply the ink color
            master_map[mask > 128] = TRAINING_COLORS[i]

        # SAVE DIRECTLY TO input_cleaned AS A FLAT FILE
        # Filename will be "Photoreal fruits.png"
        output_filename = f"{design_folder}.png"
        save_path = os.path.join(output_dir, output_filename)
        
        Image.fromarray(master_map).save(save_path)
        print(f"  [DONE] Saved merged map to: {save_path}")

if __name__ == "__main__":
    batch_merge()